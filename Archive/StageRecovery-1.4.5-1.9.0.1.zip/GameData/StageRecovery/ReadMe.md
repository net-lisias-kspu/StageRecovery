Installation:
Merge the GameData folder with the one located in the KSP directory. Delete the existing StageRecovery folder when updating to ensure compatibility.


Forum: http://forum.kerbalspaceprogram.com/threads/86677-0-24-2-StageRecovery-Recover-Funds-from-Dropped-Stages-v1-4-1-%288-22-14%29
Source: https://github.com/magico13/StageRecovery
Issue Tracker: https://github.com/magico13/StageRecovery/issues

Reporting bugs:
Please include the output_log.txt file from the KSP_Data folder if using 32 bit or the KSP_x64_Data folder if using 64 bit. Report the bug, with directions on how to reproduce it, on either the forum page or issue tracker, listed above.

